This is a Home Inventory Management software, made using Java Swing in Apache NetBeans IDE 12.0 

DIRECTIONS -

A toolbar is provided, which can be used to add, delete and save items from the inventory. It is also used to navigate from one item to the next. 
The primary way to enter information about an inventory item is with several text field controls. 
A combo box is used to specify location, while a date chooser is used to select purchase date.
Use check box control to indicate if an item is marked with identifying information. 
A button control selects a photo to display in the panel control. 
Use the panel control for quick searching.

NOTE -

This is the NetBeans Source of the project. Thus, you must use NetBeans for compiling and running. 